<?php

include 'config.php';

session_start();

$user_id = $_SESSION['user_id'];

if (!isset($user_id)) {
   header('location:login.php');
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">
   <!-- Fav-icon Link -->
   <link rel="icon" href="images/stationary-icon.png">
</head>

<style>
   h4 {
      font-size: 1.4rem !important;
      color: gray !important;
      font-weight: 600;
      font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
   }
</style>

<body>

   <?php include 'header.php'; ?>

   <div class="heading">
      <h3>about us</h3>
      <p> <a href="home.php">Home</a> / About </p>
   </div>

   <section class="about">

      <div class="flex">

         <div class="image">
            <img src="images/about-bg.png" alt="">
         </div>

         <div class="content">
            <h3>Why Choose Our Stationary Shop?</h3>
            <p>Quality You Can Trust: Absolutely reliable! We not only ensure reasonable prices but also consider trust and high standards. In everything, we guarantee you the best.</p>
            <p>Wide Range of Products: Friends, our store has all kinds of stationary items available for you to easily acquire.</p>
            <p>Personalized Service: Our team is ready to provide you with personalized assistance. According to your preferences and needs, we will provide you with convenience.</p>
            <p>Customer Satisfaction: Every customer's happiness is very important to us. We will try our best to keep you happy in every way.</p>
            <p>So buddy, whenever you need stationary items, our store is always ready for you!</p>
            <a href="contact.php" class="btn">contact us</a>
         </div>

      </div>

   </section>

   <section class="reviews">

      <h1 class="title">client's reviews</h1>

      <div class="box-container">

         <div class="box">
            <img src="images/pic-1.png" alt="">
            <p>Customer satisfaction is paramount at Stationary Shop. I have been a loyal customer for years, and every time I visit, I am greeted with warmth and professionalism. The quality of their products is unmatched, and their attention to detail is commendable.</p>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>John Deo</h3>
         </div>

         <div class="box">
            <img src="images/pic-2.png" alt="">
            <p>I stumbled upon Stationary Shop while searching for premium stationery items, and I'm glad I did. Not only do they offer a wide range of products, but the staff is also incredibly helpful. They went above and beyond to assist me in finding the perfect items for my needs.</p>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Amna Shaikh</h3>
         </div>

         <div class="box">
            <img src="images/pic-3.png" alt="">
            <p>"I am a teacher, and I rely on quality stationery supplies to enhance my classroom experience. Stationary Shop has become my top choice for all my stationery needs. Their products are durable, affordable, and always exceed my expectations.I trust and highly recommend this shop.</p>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Irfan Khan</h3>
         </div>

         <div class="box">
            <img src="images/pic-4.png" alt="">
            <p>I have purchased from this stationary shop multiple times and have always been pleased with their services. Their wide range of products and high-quality stationary always impresses me. Additionally, their customer service is excellent. I trust and highly recommend this shop.</p>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star-half-alt"></i>
               <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Atiqa Hafeez</h3>
         </div>

         <div class="box">
            <img src="images/pic-5.png" alt="">
            <p>I am a loyal customer of this stationary shop, and I have consistently found satisfaction in their products. Their staff goes above and beyond, always being helpful and cooperative. Without hesitation, I give their exceptional services a well-deserved 5-star rating.</p>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Hakim Zafar</h3>
         </div>

         <div class="box">
            <img src="images/pic-6.png" alt="">
            <p>For stationary shopping, this shop is my first choice. Their online and offline platforms are very user-friendly. The quality of their products is excellent, and the delivery time is minimal. I wholeheartedly recommend this shop without any doubt.</p>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star-half-alt"></i>
            </div>
            <h3>Anvish Somroo</h3>
         </div>

      </div>

   </section>

   <section class="authors">
      <h1 class="title">CORE TEAM</h1>

      <div class="box-container">
         <div class="box">
            <img src="images/blank_profile.jpg" alt="">
            <div class="share">
               <a href="#" class="fab fa-facebook-f"></a>
               <a href="#" class="fab fa-youtube"></a>
               <a href="#" class="fab fa-instagram"></a>
               <a href="#" class="fab fa-linkedin"></a>
            </div>
            <h3>Fakhir Ali</h3>
            <h4>Lead - Backend + some FrontEnd</h4>
            <a href="#">
               <button class="w-100 bg-dark text-white text-center">Read More</button>
            </a>
         </div>

         <div class="box">
            <img src="images/blank_profile.jpg" alt="">
            <div class="share">
               <a href="https://www.facebook.com/profile.php?id=61558055468142" class="fab fa-facebook-f"></a>
               <a href="https://www.youtube.com/@abdullahkhan3403" class="fab fa-youtube"></a>
               <a href="https://www.instagram.com/rehmanisudais0/" class="fab fa-instagram"></a>
               <a href="https://www.linkedin.com/in/sudais-rehmani-00a0b42b7/" class="fab fa-linkedin"></a>
            </div>
            <h3>Sudais Rehmany</h3>
            <h4>Developer - Back-End + Front-End</h4>
            <a href="images/Sudais Resume.pdf">
               <button class="w-100 bg-dark text-white text-center">Read More</button>
            </a>
         </div>

         <div class="box">
            <img src="images/blank_profile.jpg" alt="">
            <div class="share">
               <a href="#" class="fab fa-facebook-f"></a>
               <a href="#" class="fab fa-youtube"></a>
               <a href="#" class="fab fa-instagram"></a>
               <a href="#" class="fab fa-linkedin"></a>
            </div>
            <h3>Ahsan Ameen</h3>
            <h4>Developer - FrontEnd</h4>
            <a href="#">
               <button class="w-100 bg-dark text-white text-center">Read More</button>
            </a>
         </div>

         <div class="box">
            <img src="images/blank_profile.jpg" alt="">
            <div class="share">
               <a href="#" class="fab fa-facebook-f"></a>
               <a href="#" class="fab fa-youtube"></a>
               <a href="#" class="fab fa-instagram"></a>
               <a href="#" class="fab fa-linkedin"></a>
            </div>
            <h3>Khurram Abaas</h3>
            <h4>Developer - FrontEnd</h4>
            <a href="#">
               <button class="w-100 bg-dark text-white text-center">Read More</button>
            </a>
         </div>

         <div class="box">
            <img src="images/blank_profile.jpg" alt="">
            <div class="share">
               <a href="#" class="fab fa-facebook-f"></a>
               <a href="#" class="fab fa-youtube"></a>
               <a href="#" class="fab fa-instagram"></a>
               <a href="#" class="fab fa-linkedin"></a>
            </div>
            <h3>Noor Ali</h3>
            <h4>Developer - FrontEnd</h4>
            <a href="#">
               <button class="w-100 bg-dark text-white text-center">Read More</button>
            </a>
         </div>

         <div class="box">
            <img src="images/blank_profile.jpg" alt="">
            <div class="share">
               <a href="#" class="fab fa-facebook-f"></a>
               <a href="#" class="fab fa-youtube"></a>
               <a href="#" class="fab fa-instagram"></a>
               <a href="#" class="fab fa-linkedin"></a>
            </div>
            <h3>Sir Zulqarnain</h3>
            <h4>Advisor - Back-End + Front-End</h4>
            <a href="#">
               <button class="w-100 bg-dark text-white text-center">Read More</button>
            </a>
         </div>

      </div>
   </section>

   <?php include 'footer.php'; ?>

   <!-- custom js file link  -->
   <script src="js/script.js"></script>

</body>

</html>