<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="home.php">Home</a>
         <a href="about.php">About</a>
         <a href="shop.php">Shop</a>
         <a href="contact.php">Contact</a>
      </div>

      <div class="box">
         <h3>extra links</h3>
         <a href="login.php">Login</a>
         <a href="register.php">Register</a>
         <a href="cart.php">Cart</a>
         <a href="orders.php">Orders</a>
      </div>

      <div class="box">
         <h3>contact info</h3>
         <p> <i class="fas fa-phone"></i> Fakhir : +92-+92 318 8869599 </p>
         <p> <i class="fas fa-phone"></i> Sudais : +92 311 2941177</p>
         <p> <i class="fas fa-envelope"></i> rehmanisudais0@gmail.com </p>
         <p> <i class="fas fa-map-marker-alt"></i> Karachi, Pakistan - 75620 </p>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="https://www.facebook.com/profile.php?id=61558055468142"> <i class="fab fa-facebook-f"></i> Facebook </a>
         <a href="https://www.youtube.com/@abdullahkhan3403"> <i class="fab fa-youtube"></i> Twitter </a>
         <a href="https://www.instagram.com/rehmanisudais0/"> <i class="fab fa-instagram"></i> Instagram </a>
         <a href="https://www.linkedin.com/in/sudais-rehmani-00a0b42b7/"> <i class="fab fa-linkedin"></i> Linkedin </a>
      </div>

   </div>

   <p class="credit"> &copy; copyright  @ <?php echo date('Y'); ?> by <span><a href="home.php">Company</a></span> </p>

</section>